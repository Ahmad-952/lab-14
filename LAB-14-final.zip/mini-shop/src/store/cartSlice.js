// Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14
import { createSlice } from '@reduxjs/toolkit';

// items looks like: [{ id: 1, qty: 2 }]
const cartSlice = createSlice({
  name: 'cart',
  initialState: { items: [] },
  reducers: {
    // Increase the quantity if already in the cart, otherwise add it
    addToCart(state, action) {
      const item = state.items.find((i) => i.id === action.payload);
      if (item) item.qty += 1;
      else state.items.push({ id: action.payload, qty: 1 });
    },
    removeFromCart(state, action) {
      state.items = state.items.filter((i) => i.id !== action.payload);
    },
    clearCart(state) {
      state.items = [];
    },
  },
});

export const { addToCart, removeFromCart, clearCart } = cartSlice.actions;

export const selectCartItems = (state) => state.cart.items;
// Total number of units, used by the navbar badge
export const selectCartCount = (state) =>
  state.cart.items.reduce((sum, i) => sum + i.qty, 0);

export default cartSlice.reducer;
