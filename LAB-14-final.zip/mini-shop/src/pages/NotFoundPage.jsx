// Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14
import { Link } from 'react-router-dom';

export default function NotFoundPage() {
  return (
    <section className="empty">
      <h1>404 - Page Not Found</h1>
      <Link to="/">Go to Home</Link>
    </section>
  );
}
