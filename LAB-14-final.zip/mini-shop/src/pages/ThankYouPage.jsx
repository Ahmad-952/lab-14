// Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14
import { Link, useLocation } from 'react-router-dom';

export default function ThankYouPage() {
  // The checkout form passes the customer's name through router state
  const { state } = useLocation();
  const name = state?.name;

  return (
    <section className="empty thanks">
      <div className="thanks-icon" aria-hidden="true">🎉</div>
      <h1>Thank You{name ? `, ${name}` : ''}!</h1>
      <p>Your order has been placed successfully.</p>
      {state?.payment && <p>Payment method: {state.payment}</p>}
      <Link to="/" className="btn">Continue Shopping</Link>
    </section>
  );
}
