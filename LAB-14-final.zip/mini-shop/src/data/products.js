// Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14
// Static product list used by all pages
export const products = [
  { id: 1, title: 'React Handbook', icon: '📘', category: 'Books', price: 1200 },
  { id: 2, title: 'JavaScript Guide', icon: '📙', category: 'Books', price: 950 },
  { id: 3, title: 'Wireless Mouse', icon: '🖱️', category: 'Electronics', price: 1800 },
  { id: 4, title: 'Mechanical Keyboard', icon: '⌨️', category: 'Electronics', price: 6500 },
  { id: 5, title: 'Coffee Mug', icon: '☕', category: 'Accessories', price: 600 },
  { id: 6, title: 'Laptop Bag', icon: '💼', category: 'Accessories', price: 3200 },
];
