// Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { addToCart } from '../store/cartSlice.js';
import { toggleWish, selectWishIds } from '../store/wishlistSlice.js';

export default function ProductCard({ product }) {
  const dispatch = useDispatch();
  const wishIds = useSelector(selectWishIds);
  const isWished = wishIds.includes(product.id);

  return (
    <article className="card">
      {/* Coloured picture area, one colour per category */}
      <div className={`thumb ${product.category.toLowerCase()}`} aria-hidden="true">
        {product.icon}
      </div>
      <span className="tag">{product.category}</span>
      <h3>
        <Link to={`/product/${product.id}`}>{product.title}</Link>
      </h3>
      <p className="price">Rs. {product.price.toLocaleString()}</p>
      <button type="button" className="btn cart" onClick={() => dispatch(addToCart(product.id))}>
        Add to Cart
      </button>
      <button
        type="button"
        className={isWished ? 'btn wished' : 'btn outline'}
        onClick={() => dispatch(toggleWish(product.id))}
      >
        {isWished ? 'Wished' : 'Wish'}
      </button>
    </article>
  );
}
